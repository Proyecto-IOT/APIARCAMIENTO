//
//  TabBarController.swift
//  APIARCAMIENTO
//
//  Created by Mac24 on 13/03/24.
//

import UIKit

class TabBarController: UITabBarController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.selectedIndex = 1
        let use = UserDefaults.standard
    }
    
}
